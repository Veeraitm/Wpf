﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace DataAccess
{
   
    public class DAL
    {
        private EmployeeEntity empdb = new EmployeeEntity();

        public void Add(Employee emp)
        {
            empdb.Employees.Add(emp);
            empdb.SaveChanges();
        }
        public List<Employee> GetAll()
        {
            return empdb.Employees.ToList();
        }
        public void Update(Employee emp)
        {
            
        }
        public void Delete(Employee emp)
        {
            empdb.Employees.Remove(emp);
        }
    }
}

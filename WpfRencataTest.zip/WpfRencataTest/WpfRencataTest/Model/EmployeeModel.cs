﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfRencataTest.Model
{
    public class EmployeeModel
    {
        private string _empID;
        private string _empName;
        private string _designation;
        private int _age;
        private string _address1;
        private string _address2;

        public string EmpID
        {
            get
            {
                return _empID;
            }
            set
            {
                _empID = value;
            }
        }

        public string EmpName
        {
            get
            {
                return _empName;
            }
            set
            {
                _empName = value;
            }
        }

        public string Designation
        {
            get
            {
                return _designation;
            }
            set
            {
                _designation = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }


        public string Address1
        {
            get
            {
                return _address1;
            }
            set
            {
                _address1 = value;
            }
        }

    //    public string Address2
    //    {
    //        get
    //        {
    //            return _address2;
    //        }
    //        set
    //        {
    //            _address2 = value;
    //        }
    //    }
    }
}

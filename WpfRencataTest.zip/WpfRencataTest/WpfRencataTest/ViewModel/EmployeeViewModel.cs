﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfRencataTest.Command;
using WpfRencataTest.Model;
using DataAccess;
using WpfRencataTest.EmployeeService;

namespace WpfRencataTest.ViewModel
{
  public class EmployeeViewModel : ViewModelBase
    {
        EmployeeService.EmployeeServiceClient _service;
        public EmployeeViewModel()
        {
            Employee = new EmployeeModel();
            Employees = new ObservableCollection<EmployeeModel>();
            _service = new EmployeeService.EmployeeServiceClient();
        }

        private EmployeeModel _employee;
        private ObservableCollection<EmployeeModel> _employees;
        private ICommand _SubmitCommand;
        private ICommand _SerachCommand;
        private ICommand _updateCommand;
        private ICommand _deleteCommand;
        private ICommand _SelectedRowCommand;

        public EmployeeModel Employee
        {
            get
            {
                return _employee;
            }
            set
            {
                _employee = value;
                OnPropertyChanged("Employee");
            }

        }

        public ObservableCollection<EmployeeModel> Employees
        {
            get
            {
                return _employees;
            }
            set
            {
                _employees = value;
                OnPropertyChanged("Employees");
            }

        }

        public ICommand SubmitCommand
        {
            get
            {
                if (_SubmitCommand == null)
                {
                    _SubmitCommand = new RelayCommand(param => this.Submit(), null);
                }
                return _SubmitCommand;
            }
        }

        public ICommand SearchCommand
        {
            get
            {
                if (_SerachCommand == null)
                {
                    _SerachCommand = new RelayCommand(param => this.Search(), null);
                }
                return _SerachCommand;
            }
        }

        public ICommand UpdateCommand
        {
            get
            {
                if (_updateCommand == null)
                {
                    _updateCommand = new RelayCommand(param => this.Update(), null);
                }
                return _updateCommand;
            }
        }

        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new RelayCommand(param => this.Delete(), null);
                }
                return _deleteCommand;
            }
        }

        public ICommand SelectedRowCommand
        {
            get
            {
                if (_SelectedRowCommand == null)
                {
                    _SelectedRowCommand = new RelayCommand(param => this.SelectionChanged(param), null);
                }
                return _SelectedRowCommand;
            }
        }



        private void Submit()
        {
            EmployeeService.Employee emp = new EmployeeService.Employee();
            emp.EmpID = Employee.EmpID;
            emp.Designation = Employee.Designation;
            emp.EmpName = Employee.EmpName;
            emp.Age = Employee.Age;
            emp.Address1 = Employee.Address1;
            _service.Add(emp);

        }
        private void Search()
        {
            EmployeeModel emp = this.Employees.FirstOrDefault(e => e.EmpID == this.Employee.EmpID);
            this.Employee.EmpName = emp.EmpName;
            this.Employee.Designation = emp.Designation;
            this.Employee.Age = emp.Age;
            OnPropertyChanged("Employee");
        }

        private void Update()
        {
            EmployeeModel emp = this.Employees.FirstOrDefault(e => e.EmpID == this.Employee.EmpID);
            emp.EmpName = this.Employee.EmpName;
            emp.Designation = this.Employee.Designation;
            emp.Age = this.Employee.Age;
            OnPropertyChanged("Employees");
        }

        private void Delete()
        {
            EmployeeModel emp = this.Employees.FirstOrDefault(e => e.EmpID == this.Employee.EmpID);
            this.Employees.Remove(emp);
            OnPropertyChanged("Employees");
        }

        private void SelectionChanged(object param)
        {
            Employee = (EmployeeModel)param;
        }

    }
}

